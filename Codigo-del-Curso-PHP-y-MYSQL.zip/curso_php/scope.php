<?php

$numero = 7;

function mostrarNumero(){
	$numero = 10;
	// return $numero;
}

echo mostrarNumero();

?>