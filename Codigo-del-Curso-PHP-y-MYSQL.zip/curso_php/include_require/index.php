<?php 

function suma($numero, $numero2){
	return $numero + $numero2;
}

require 'vista.php';

?>