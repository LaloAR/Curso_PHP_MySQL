<?php 

$numero = 15.185;

// echo round($numero, 3);

// echo rand(1,10);

// echo ceil(12.001);

echo M_PI;

?>