<?php 

echo "Soy un echo";

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<h1>Hola Mundo</h1>
	<?php die(); ?>
</body>
</html>