<?php 

define('RUTA', 'http://localhost/curso_php/Practicas/blog');

$bd_config = array(
	'basedatos' => 'blog_practica',
	'usuario' => 'root',
	'pass' => ''
);

$blog_config = array(
	'post_por_pagina' => '2',
	'carpeta_imagenes' => 'imagenes/'
);

$blog_admin = array(
	'usuario' => 'Carlos',
	'password' => '123'
);

?>