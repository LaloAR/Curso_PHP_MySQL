<?php

# Las constantes nos permiten almacenar un valor y poder acceder de forma global a el.
# Nota: Las constantes a diferencia de las variables no se pueden sobreescribir.
define('PI', 3.14);
define('NOMBRE', 'Carlos');

echo NOMBRE;

# Ejemplo de variable sobreescrita.
// $nombre = "Carlos";
// $nombre = "Arturo";
// echo $nombre;

?>